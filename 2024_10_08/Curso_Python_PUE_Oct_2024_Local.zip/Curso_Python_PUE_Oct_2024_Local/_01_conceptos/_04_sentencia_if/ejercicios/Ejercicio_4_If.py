# Realizar un programa que solicite un importe por teclado y,
# calcule el importe total en base al siguiente criterio:
# El tipo de descuento base será del 21 porciento
# tipo_descuento = 21
# descuento = importe * tipo_descuento / 100
# importe_total = importe - descuento
# El tipo de descuento variará en función del importe introducido y,
# variará según las distintas cantidades:
# - Si importe es menor de 100, no se aplicará el descuento
# - Si importe es menor de 5000, se aplicará el descuento base
# - Si importe es menor de 25000, se aplicará el (descuento base - 10)
# - Si importe es menor o igual a 50000, se aplicará el (descuento base - 15)
# - Si importe es mayor de 50000, se aplicará el (descuento base - 19)

# Mostrar en pantalla el importe total de la cantidad introducida

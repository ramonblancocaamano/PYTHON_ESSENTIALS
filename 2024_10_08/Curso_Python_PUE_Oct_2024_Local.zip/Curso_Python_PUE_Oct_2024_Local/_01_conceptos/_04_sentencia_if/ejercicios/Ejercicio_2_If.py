# Realizar un programa que solicite un número por teclado
# y muestre en pantalla si es divisible entre 5 o si es
# divisible entre 2

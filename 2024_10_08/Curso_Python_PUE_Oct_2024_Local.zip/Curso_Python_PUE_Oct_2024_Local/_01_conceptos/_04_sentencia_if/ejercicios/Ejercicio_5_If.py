# Realizar un programa que solicite por teclado tres valores numéricos y,
# Muestre en pantalla cuál es el número mayor, cuál es el número menor o si
# son todos iguales.

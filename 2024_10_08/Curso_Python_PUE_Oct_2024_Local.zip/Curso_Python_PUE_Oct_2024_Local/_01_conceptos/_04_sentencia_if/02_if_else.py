# ------------------------------------------------------------------------------------------
# Sentencia if else
# ------------------------------------------------------------------------------------------

numero = int(input("Numero: "))
es_par = numero % 2 == 0
if es_par == True:
    print("Has introducido un numero par")
else:
    print("Has introducido un numero impar")

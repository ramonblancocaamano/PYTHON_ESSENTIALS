# ------------------------------------------------------------------------------------------
# Ejemplos de operadores de asignación
# ------------------------------------------------------------------------------------------

# Asignamos el valor 34 a la variable denominada 'numero'
numero = 34
print(numero) # Visualizamos el valor de la variable 'numero'

# Asignamos el valor 1.86 a la variable denominada 'altura'
altura = 1.86
print(altura) # Visualizamos el valor de la variable 'altura'

# Asignamos el valor 'Ara Lences' a la variable denominada 'nombre'
nombre = 'Ara Lences'
print(nombre) # Visualizamos el valor de la variable 'nombre'

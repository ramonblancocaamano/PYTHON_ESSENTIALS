# Realizar un programa que solicite por teclado diez números y
# calcule cuantos números introducidos son mayores de cinco

# Realizar un programa que un número por teclado y calcule
# el sumatorio del número introducido y el resultado se muestre
# por pantalla


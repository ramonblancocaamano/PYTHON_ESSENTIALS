# Realizar un programa que solicite por teclado diez números y
# calcule cuántos números introducidos fueron divisibles entre siete

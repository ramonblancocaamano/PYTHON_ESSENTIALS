# Realizar un programa que solicite por teclado un número (mientras
# el número introducido sea distinto de cero) y, calcule el número
# total de números pares e impares y, la suma total de todos los números
# pares y la suma total de todos los números impares.
# Mostrar en pantalla el número total de números pares e impares y,
# mostrar en pantalla la suma totatl de todos los números pares e impares

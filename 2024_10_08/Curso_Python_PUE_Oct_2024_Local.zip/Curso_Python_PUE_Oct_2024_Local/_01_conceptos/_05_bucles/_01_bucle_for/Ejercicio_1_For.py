# Realizar un programa que solicite un número por teclado y muestre
# en pantalla la tabla de multiplicar del 1 al 10 del número introducido

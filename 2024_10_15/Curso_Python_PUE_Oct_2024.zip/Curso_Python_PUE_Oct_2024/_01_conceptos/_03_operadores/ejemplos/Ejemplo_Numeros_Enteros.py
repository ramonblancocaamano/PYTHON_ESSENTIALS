numero = 1
print(numero, len(str(numero)))

v = '7,8'
f = float(v)

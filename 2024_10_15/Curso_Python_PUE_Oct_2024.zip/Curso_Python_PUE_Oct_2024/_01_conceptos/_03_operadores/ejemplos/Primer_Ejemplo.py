# Realizar un programa que solicite dos números por teclado y, calcular
# la multiplicación de los dos números y mostrar en pantalla el
# resultado de la multiplicación

primer_numero = int(input("Primer número: "))
segundo_numero = int(input("Segundo número: "))
multiplica = primer_numero * segundo_numero
print("La multiplicacion es", multiplica)


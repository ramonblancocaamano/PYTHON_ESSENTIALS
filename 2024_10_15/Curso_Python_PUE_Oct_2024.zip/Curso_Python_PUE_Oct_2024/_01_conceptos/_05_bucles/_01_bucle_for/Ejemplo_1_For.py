# Mostrar en pantalla los números divisibles entre 7, desde 0 hasta
# el número introducido por teclado
n = int(input('Números: '))
for k in range(7, n, 7):
    print(k)

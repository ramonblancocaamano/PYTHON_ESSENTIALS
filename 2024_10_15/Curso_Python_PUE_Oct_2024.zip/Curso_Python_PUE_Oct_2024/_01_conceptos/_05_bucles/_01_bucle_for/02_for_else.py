for x in range(7):
    print(x)
else:
    print("Finalizado correctamente")

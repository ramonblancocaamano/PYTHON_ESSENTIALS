# Realizar un programa que solicite por teclado un número (mientras
# el número introducido sea distinto de cero) y, calcule el número total
# de números divisibles entre dos, tres y siete.
# Mostrar en pantalla el número total de números divisibles entre dos, tres y siete

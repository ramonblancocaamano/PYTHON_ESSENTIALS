# Realizar un programa que realice la división entre dos números
# introducidos por teclado, uno para el número a dividir y
# otro para el divisor.
# Si el divisor es igual a cero mostramos en pantalla el
# siguiente mensaje: 'Error: Esta división no se puede realizar'
# en caso contrario realizamos la división y mostramos en
# pantalla el resultado de la división

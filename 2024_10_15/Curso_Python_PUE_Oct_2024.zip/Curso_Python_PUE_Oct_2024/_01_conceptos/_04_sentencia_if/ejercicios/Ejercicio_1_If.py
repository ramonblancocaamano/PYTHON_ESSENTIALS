# Realizar un programa que solicite una edad por teclado
# y muestre en pantalla el mensaje 'Es mayor de edad' en caso
# de que la edad introducida sea mayor de 17.
# En caso contrario no se hace nada

# ------------------------------------------------------------------------------------------
# Sentencia if simple
# ------------------------------------------------------------------------------------------
"""
Sintáxis:
if condición o expresión booleana:
    sentencias de if
elif condición o expresión booleana:
    sentencias de elif
else:
    sentencias si no se cumple la condición o expresión booleana
"""
edad = 17
if edad > 18:
    print("Es mayor de edad")

numero = int(input("Numero: "))
if (numero % 2) == 1:
    print("Has introducido un numero impar")

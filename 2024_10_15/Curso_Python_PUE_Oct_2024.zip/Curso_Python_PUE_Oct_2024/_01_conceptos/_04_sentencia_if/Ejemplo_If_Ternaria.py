num = int(input('Número: '))
print('El número es mayor de 7') if num > 7 else None

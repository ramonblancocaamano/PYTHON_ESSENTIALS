# ------------------------------------------------------------------------------------------
# Sentencia if completa
# ------------------------------------------------------------------------------------------

dia_semana = int(input("Dia de semana: ")) # 1 y 7
if dia_semana == 1:
    print("Lunes")
elif dia_semana == 2:
    print("Martes")
elif dia_semana == 3:
    print("Miércoles")
elif dia_semana == 4:
    print("Jueves")
elif dia_semana == 5:
    print("Viernes")
elif dia_semana == 6:
    print("Sábado")
elif dia_semana == 7:
    print("Lunes")
else:
    print("Debe de introducir un número entre 1 y 7")

print('Fin programa')
